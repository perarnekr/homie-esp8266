module.exports = {
	extends: "athom",
};